# Aplikasi Kasir (Versi 1) Sederhana Menggunakan Php + Mysql + Bootstrap

Dibuat dalam studi kasus Toko Modern yang menggunakan barcode.

Aplikasi ini benar benar cocok untuk pemula yang mau belajar PHP dan Mysql dari dasar.

## Tutorial ada di youtube
<p>Eps 1 => https://www.youtube.com/watch?v=a8aQbhu64Cc</p>
<p>Eps 6 => https://www.youtube.com/watch?v=eEh3X9fgWIA</p>


Klik channel saya untuk lebih banyak lagi video tutorial
